create procedure delete_by_name_or_phone(IN cont text)
    language plpgsql
as
$$
    BEGIN
        DELETE FROM phonebook
        WHERE (contact = cont) or phone_num = cont;
    END;
$$;

alter procedure delete_by_name_or_phone(text) owner to postgres;

