create procedure insert(IN new_contact text, IN new_phone text)
    language plpgsql
as
$$
    BEGIN
        perform * from phonebook
        where contact = new_contact;
        if not found then
            INSERT INTO phonebook(contact, phone_num) VALUES (new_contact, new_phone);
        else
            UPDATE phonebook SET phone_num = new_phone WHERE contact = new_contact;
        end if;
    end;
$$;

alter procedure insert(text, text) owner to postgres;

