create procedure insert_by_console(IN new_contact text[], IN new_phone text[])
    language plpgsql
as
$$
    BEGIN
        for counter in 1..array_length(new_contact,1) loop
            perform * from phonebook
            where contact = new_contact[counter];
            if not found then
                INSERT INTO phonebook(contact, phone_num) VALUES (new_contact[counter], new_phone[counter]);
            else
                UPDATE phonebook SET phone_num = new_phone[counter] WHERE contact = new_contact[counter];
            end if;
        end loop;
    end;

$$;

alter procedure insert_by_console(text[], text[]) owner to postgres;

