create procedure update(IN new_contact text, IN new_phone text)
    language plpgsql
as
$$
    BEGIN
        UPDATE phonebook SET phone_num = new_phone WHERE contact = new_contact;
    end;
$$;

alter procedure update(text, text) owner to postgres;

