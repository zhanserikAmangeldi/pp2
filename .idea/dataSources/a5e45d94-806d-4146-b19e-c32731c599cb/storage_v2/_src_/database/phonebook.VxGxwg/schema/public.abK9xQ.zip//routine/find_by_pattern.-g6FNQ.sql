create function find_by_pattern(patt text) returns text
    language plpgsql
as
$$
DECLARE
	temps text;
BEGIN
	SELECT (human_id, contact, phone_num)
	INTO temps
	FROM phonebook
	WHERE contact LIKE patt;

	return temps;
END;
$$;

alter function find_by_pattern(text) owner to postgres;

